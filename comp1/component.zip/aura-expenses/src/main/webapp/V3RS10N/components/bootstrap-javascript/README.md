## Quick start

Three quick start options are available:

* [Download the latest release](https://github.com/alisamar/bootstrap-javascript/zipball/master).
* Clone the repo: `git clone git://github.com/alisamar/bootstrap-javascript.git`.
* Install with Twitter's [Bower](http://twitter.github.com/bower): `bower install bootstrap-javascript`.
