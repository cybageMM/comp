module.exports = function (grunt) {
    require('matchdep').filterDev('grunt-*').forEach(grunt.loadNpmTasks);
    var fs = require('fs');
    // read in bower config to pull in name and version
    var bower = grunt.file.readJSON('bower.json');
    var dateFormat = require('dateformat');
    var today = dateFormat(new Date(), "yyyymmdd.hhMMss");

    var gruntConfig = {
        app: 'src/main/webapp',
        dist: 'target/dist',
        // ensure the name and version properties in bower.json are correct, as they control much of the build
        name: bower.name,
        version: bower.version,
        description: 'Mediaocean Aura Application - Expenses',
        svnRepo: 'https://svn.gomocean.info/svn/rodick/',
        svnProject: bower.name,
        nexusFolder: 'dds-snapshots',
        nexusGroupId: 'com.mediaocean.spectra.rodick',
        nexusArtifactId: bower.name,
        // end of project-specific settings
        deployDir: 'target/tmp',
        pomDir: 'target/pom'
    };
    gruntConfig.appVersionDir = gruntConfig.app + '/V3RS10N';
    gruntConfig.distVersionDir = gruntConfig.dist + '/V3RS10N';

    // parse version for branch and snapshot handling
    var verParts = gruntConfig.version.split('.');

    // set svn source based on whether branch build requested or not
    if (grunt.option('branch')) {
    	grunt.log.writeln('branch option detected');
        gruntConfig.svnTagSource = 'branches/' + gruntConfig.name + '-' + verParts[0] + '.' + verParts[1] + '/';
    }
    else {
        gruntConfig.svnTagSource = 'trunk/brandocean-rodick-parent/';
    }
    grunt.log.writeln('svnTagSource=' + gruntConfig.svnTagSource);

    // set config based on release/snapshot (if release not specified then assume snapshot)
    if (grunt.option('release')) {
    	grunt.log.writeln('release option detected');
        // set nexus folder for releases
        gruntConfig.nexusFolder = 'dds-releases';
    }
    else {
        // set nexus folder for snapshots
        gruntConfig.nexusFolder = 'dds-snapshots';
        // replace version with snapshot version
        gruntConfig.version = verParts[0] + '.' + verParts[1] + '-SNAPSHOT';
    }
    grunt.log.writeln('nexusFolder=' + gruntConfig.nexusFolder);
    grunt.log.writeln('version=' + gruntConfig.version);

    // set tag name for svn.
    gruntConfig.tagName = gruntConfig.name + '-' + gruntConfig.version;
    grunt.log.writeln('tagName=' + gruntConfig.tagName);
    gruntConfig.zipFile = gruntConfig.deployDir + '/' + gruntConfig.name + '-' + gruntConfig.version + (grunt.option('release') ? '' : '-' + today) + '.zip';
    grunt.log.writeln('zipFile=' + gruntConfig.zipFile);
    // Messages used by svn shell task
    var commitMsg = {
        msgCommit: 'Updated version for next build',
        msgTag: 'Release of ' + gruntConfig.version,
        msgJenkins: '[grunt-release]'
    };
    // List all the files in the templates directory, to be included in the requirejs optimization.
    // This is only necessary when using knockout amd helpers, as templates not referenced in modules.
    var templateDir = [];
    fs.readdirSync(gruntConfig.appVersionDir + '/templates').forEach(function (filename) {
        if (filename.substr(-4) === 'html') {
            // Only include files that have the html suffix.
            templateDir.push('text!../templates/' + filename);
        }
        else {
            //if other than HTML files are present e.g. folders then include folder files as well
            fs.readdirSync(gruntConfig.appVersionDir + '/templates/' + filename).forEach(function (file) {
                if (file.substr(-4) === 'html') {
                    // Only include files that have the html suffix.
                    templateDir.push('text!../templates/' + filename + '/' + file);
                }
            });
        }
    });
    grunt.initConfig({
        gruntConfig: gruntConfig,
        pkg: grunt.file.readJSON('package.json'),

        htmlmin: {
            build: {
                options: {
                    removeComments: false,
                    collapseWhitespace: true
                },
                files: [
                    {
                        expand: true,
                        cwd: '<%= gruntConfig.app%>/V3RS10N/templates/',
                        src: '**/*.html',
                        dest: '<%= gruntConfig.dist %>/V3RS10N/templates'
                    },
                    {
                        '<%= gruntConfig.dist %>/index.html': '<%= gruntConfig.app%>/index.html'
                    }
                ]
            }
        },
        bower: {
            install: {
                options: {
                    install: true,
                    copy: false,
                    targetDir: '<%= gruntConfig.app%>/V3RS10N/components'
                }
            }

        },
        compass: {
            options: {
                sassDir: '<%= gruntConfig.app %>/V3RS10N/sass',
                cssDir: '<%= gruntConfig.app %>/V3RS10N/css',
                force: true,
                importPath: [
                    '<%= gruntConfig.app %>/V3RS10N/components/mediaocean-patterns/bootstrap2',
                    '<%= gruntConfig.app %>/V3RS10N/components/mediaocean-patterns/bootstrap2/mediaocean'
                ]
            },
            dist: {}
        },
        copy: {
            version: {
                files: [
                    {
                        expand: true,
                        cwd: '<%= gruntConfig.dist %>/V3RS10N',
                        src: ['**/*'],
                        dest: '<%= gruntConfig.dist %>/<%= gruntConfig.version %>/'
                    }
                ]
            },
            componentCSS: {
                files: [
                    {
                        expand: true,
                        cwd: '<%= gruntConfig.app %>/V3RS10N/components/fontawesome/css',
                        src: ['font-awesome.css', '*.png', '*.gif'],
                        dest: '<%= gruntConfig.app %>/V3RS10N/css/components/fontawesome/css'
                    },
                    {
                        expand: true,
                        cwd: '<%= gruntConfig.app %>/V3RS10N/components/fontawesome/fonts',
                        src: ['*.*'],
                        dest: '<%= gruntConfig.app %>/V3RS10N/css/components/fontawesome/fonts'
                    },
                    {
                        expand: true,
                        cwd: '<%= gruntConfig.app %>/V3RS10N/components/handsontable-pro/dist',
                        src: ['*.css', '*.png', '*.gif'],
                        dest: '<%= gruntConfig.app %>/V3RS10N/css/components/handsontable-pro'
                    },
                    {
                        expand: true,
                        cwd: '<%= gruntConfig.app %>/V3RS10N/components/mediaocean-handsontable/css/',
                        src: ['*.css', '*.png', '*.gif'],
                        dest: '<%= gruntConfig.app %>/V3RS10N/css/components/mediaocean-handsontable'
                    },
                    {
                        expand: true,
                        cwd: '<%= gruntConfig.app %>/V3RS10N/components/mediaocean-patterns/bootstrap2/fonts',
                        src: ['*.*'],
                        dest: '<%= gruntConfig.app %>/V3RS10N/css/components/mediaocean-patterns/fonts'
                    },
                    {
                        expand: true,
                        cwd: '<%= gruntConfig.app %>/V3RS10N/components/select2/',
                        src: ['*.css', '*.png', '*.gif'],
                        dest: '<%= gruntConfig.app %>/V3RS10N/css/components/select2'
                    },
                    {
                        expand: true,
                        cwd: '<%= gruntConfig.app %>/V3RS10N/vendor/jquery-highlighttextarea',
                        src: ['*.css', '*.png', '*.gif'],
                        dest: '<%= gruntConfig.app %>/V3RS10N/css/components/jquery-highlighttextarea'
                    }
                ]
            }
        },
        sed: {
            version: {
                path: '<%= gruntConfig.dist %>',
                pattern: 'V3RS10N',
                replacement: '<%= gruntConfig.version %>',
                recursive: true
            }
        },
        clean: {
            dist: '<%= gruntConfig.dist %>',
            deploy: ['<%= gruntConfig.deployDir %>', '<%= gruntConfig.pomDir %>'],
            version: ['<%= gruntConfig.dist %>/V3RS10N'],
            full: {
                dot: true,
                src: [
                    '<%= gruntConfig.dist %>/*',
                    '<%= gruntConfig.app %>/V3RS10N/components',
                    'node_modules'
                ]
            },
            build: {
                files: [
                    {
                        dot: true,
                        src: [
                            // delete sass folder (only css is used at runtime)
                            '<%= gruntConfig.dist %>/<%= gruntConfig.version %>/sass/',
                            // only delete css files from css folders (i.e. leave images, fonts, etc.)
                            '<%= gruntConfig.dist %>/<%= gruntConfig.version %>/css/**/*.css',
                            // don't delete the one css file that includes them all (and is referenced in index.html)
                            '!<%= gruntConfig.dist %>/<%= gruntConfig.version %>/css/main.css',
                            // delete all components except requirejs, as that kicks off everything (and is referenced in index.html)
                            '<%= gruntConfig.dist %>/<%= gruntConfig.version %>/components/**/*',
                            '!<%= gruntConfig.dist %>/<%= gruntConfig.version %>/components/requirejs',
                            '!<%= gruntConfig.dist %>/<%= gruntConfig.version %>/components/requirejs/require.js',
                            // delete application source files that we told require about manually
                            '<%= gruntConfig.dist %>/<%= gruntConfig.version %>/templates',
                            // delete build artifact
                            '<%= gruntConfig.dist %>/build.txt'
                        ]
                    }
                ]
            }
        },
        watch: {
            compass: {
                files: '<%= gruntConfig.app %>/V3RS10N/sass/*.scss',
                tasks: ['compass']
            }
        },
        requirejs: {
            compile: {
                options: {
                    mainConfigFile: '<%= gruntConfig.app %>/V3RS10N/js/main.js',
                    appDir: "<%= gruntConfig.app %>",
                    removeCombined: true,
                    optimize: 'none',
                    baseUrl: "V3RS10N/js",
                    dir: '<%= gruntConfig.dist %>',
                    modules: [
                        {
                            name: 'main',
                            include: templateDir
                        }
                    ],
                    paths: {
                        /* The mediaocean.* scripts are downloaded from the CDN, use empty: to avoid compile issues. */
                        'mediaocean.viewport': 'empty:',
                        'mediaocean.session': 'empty:',
                        'mediaocean.i18n': 'empty:'
                    }
                }
            }
        },
        uglify: {
            options: {
                mangle: false,
                compress: false,
                preserveComments: 'some',
                screw_ie8: true
            },
            build: {
                files: {
                    '<%= gruntConfig.dist %>/<%= gruntConfig.version %>/js/main.js': ['<%= gruntConfig.dist %>/<%= gruntConfig.version %>/js/main.js']
                }
            }
        },
        compress: {
            main: {
                options: {
                    archive: gruntConfig.zipFile
                },
                files: [
                    {
                        expand: true,
                        cwd: gruntConfig.dist,
                        src: ['**'],
                        dest: ''
                    }
                ]
            }
        },
        karma: {
            unit: {
                configFile: 'karma.config.js',
                runnerPort: 9999,
                singleRun: true,
                browsers: ['PhantomJS'],
                reporters: ['dots', 'coverage', 'junit'],
                coverageReporter: {
                    reporters: [
                        {
                            type: 'lcov',
                            dir: 'target/karma-coverage/',
                            subdir: '.',
                            file: 'lcov.info'
                        }
                    ]
                },
                junitReporter: {
                    outputFile: 'target/surefire-reports/TEST-com.mediaocean.js.UnitTest.xml'
                }
            }
        },
        http: {
            runSonarJob: {
                options: {
                    url: 'https://jenkins.gomocean.info/view/Sonar%20Analysis/job/aura-expenses-snapshot-analysis/build',
                    method: 'POST',
                    auth: {user: 'jenkinssvc', pass: 'ed8aa41cd9141fd8578a4d3124a15475'}
                }
            }
        },
        sonarRunner: {
            analysis: {
                options: {
                    debug: true,
                    separator: '\n',
                    sonar: {
                        host: {
                            url: 'http://sonar.mediaocean.com/'
                        },
                        projectKey: 'aura-expenses',
                        projectName: 'Aura Expenses',
                        projectVersion: gruntConfig.version,
                        sources: 'src/main/webapp/V3RS10N/js',
                        tests: 'src/test/spec',
                        language: 'js',
                        sourceEncoding: 'UTF-8',
                        javascript: {
                            lcov: {
                                reportPath: '<%= gruntConfig.target %>/karma-coverage/lcov.info' // point to code coverage from karma test.
                            }
                        }
                    }
                }
            }
        },
        nexusDeployer: {
            deploy: {
                options: {
                    groupId: gruntConfig.nexusGroupId,
                    artifactId: gruntConfig.nexusArtifactId,
                    version: '<%= gruntConfig.version %>',
                    packaging: 'zip',
                    auth: {
                        username: 'jenkins',
                        password: 'dds@jenk87'
                    },
                    pomDir: gruntConfig.pomDir,
                    url: 'http://nexus.rho.dds.net/nexus/content/repositories/' + gruntConfig.nexusFolder,
                    artifact: gruntConfig.zipFile,
                    cwd: ''
                }
            }
        },

        //increment version number
        version: {
            options: {
                pkg: 'bower.json',  //where to look for the variable version to increment
                release: 'patch'    //semantic versioning
            },
            src: ['bower.json', 'package.json'] //will update value of any variables named version in these files
        },

        //shell commands -svn check in, svn create tag
        shell: {
            // creates tag for new version
            svnTag: {
                command: 'svn copy --username jenkins --password j1mghcy5F --no-auth-cache ' +
                gruntConfig.svnRepo + gruntConfig.svnTagSource + (grunt.option('branch') ? '' : gruntConfig.svnProject + '/') + ' ' +
                gruntConfig.svnRepo + 'tags/' + gruntConfig.tagName +
                ' -m "' + commitMsg.msgJenkins + ' ' + commitMsg.msgTag + '"'
            },
            // commits changes to files (bower.json and package.json) after version update
            svnCommit: {
                command: 'svn commit --username jenkins --password j1mghcy5F --no-auth-cache -m "' + commitMsg.msgJenkins + ' ' + commitMsg.msgCommit + '" -q'
            }
        }
    });

    grunt.registerTask('server', function (target) {
        grunt.task.run([
            'connect:dev',
            'watch'
        ]);
    });
    grunt.registerTask('test', [
        'karma'              // run the test cases
    ]);
    grunt.registerTask('default', [
        'bower',
        'compass'
    ]);

    grunt.registerTask('build', [
        'clean:dist',
        'compass',
        'copy:componentCSS',
        'test',
        'requirejs',
        'htmlmin:build',
        'copy:version',
        'sed:version',
        'clean:version',
        'clean:build',
        'uglify:build'
    ]);

    grunt.registerTask('snapshot', [
        'build',
        'compress',         // create zip
        'nexusDeployer',    // deploy zip to nexus
        'clean:deploy'      // clean up
    ]);

    grunt.registerTask('release', [
        'build',
        'shell:svnTag',     // create tag
        'compress',         // create zip
        'nexusDeployer',    // deploy zip to nexus
        'version',          // update version number
        'shell:svnCommit',  // commit files with version number changes
        'clean:deploy'      // clean up
    ]);

    grunt.registerTask('printConfig', function () {
        if (grunt.option('all')) {
            grunt.log.writeln(JSON.stringify(grunt.config(), null, 2));
        }
        else {
            grunt.log.writeln(JSON.stringify(grunt.config().gruntConfig, null, 2));
            grunt.log.writeln(JSON.stringify(grunt.config().nexusDeployer.deploy.options, null, 2));
        }
    });

    grunt.registerTask('sonar', [
        'sonarRunner'
    ]);

};