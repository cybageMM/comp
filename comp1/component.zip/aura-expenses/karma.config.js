// Karma configuration
// Generated on Thu Mar 13 2014 10:42:36 GMT-0700 (PDT)

module.exports = function (config) {
    config.set({

        // base path that will be used to resolve all patterns (eg. files, exclude)
        basePath: './',


        // frameworks to use
        // available frameworks: https://npmjs.org/browse/keyword/karma-adapter
        frameworks: ['jasmine', 'requirejs'],


        // list of files / patterns to load in the browser
        files: [

            // test js
            {pattern: 'src/test/lib/jquery.js', watched: false, included: true, served: true},
            {pattern: 'src/test/lib/jasmine-jquery.js', watched: false, included: true, served: true},
            {pattern: 'src/test/spec/**/*Spec.js', included: false},

            // test fixtures
            {pattern: 'src/test/fixture/**/*.json', served: true, included: false},

            // app js
            {pattern: 'src/main/webapp/V3RS10N/js/**/*.js', included: false},
            {pattern: 'src/main/webapp/V3RS10N/js/**/**/*.js', included: false},
            {pattern: 'src/main/webapp/V3RS10N/templates/**/*.html', watched: true, included: false, served: true},
            {pattern: 'src/main/webapp/V3RS10N/components/**/*.js', included: false},
            {pattern: 'src/main/webapp/V3RS10N/vendor/**/*.js', included: false, served: true},
            {pattern: 'src/main/webapp/V3RS10N/lib/**/*.js', included: false, served: true},
            {pattern: 'src/main/webapp/V3RS10N/lib/**/*.html', included: false},

            // main js
            'src/test/testMain.js'
        ],


        // list of files to exclude
        exclude: [

        ],


        // pre-process matching files before serving them to the browser
        // available preprocessors: https://npmjs.org/browse/keyword/karma-preprocessor
        preprocessors: {
            'src/main/webapp/V3RS10N/js/**/*.js': ['coverage']
        },

        // test results reporter to use
        // possible values: 'dots', 'progress'
        // available reporters: https://npmjs.org/browse/keyword/karma-reporter
        reporters: ['progress', 'coverage'],

        coverageReporter: {
            type: 'html',
            dir: 'src/test/coverage/'
        },


        // web server port
        port: 9876,


        // enable / disable colors in the output (reporters and logs)
        colors: true,


        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
        logLevel: config.LOG_INFO,


        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: false,


        // start these browsers
        // available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
        browsers: ['Chrome'],


        // Continuous Integration mode
        // if true, Karma captures browsers, runs the tests and exits
        singleRun: false
    });
};