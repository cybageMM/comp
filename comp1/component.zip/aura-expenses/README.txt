Overview
========
The aura-expenses project contains a basic static HTML/JavaScript component
designed to be hosted in the the Viepwort:
(http://prv.aos.delta.dds.net/viewport-home).


Set Up
======
The component is designed to run under the Viewport and makes calls to several
services. There are two ways to run the componet, one is locally and the other
is to use FoxyProxy to run it inside the Viewport.  Both ways require a local
Apache httpd server.

Javascript / Build Tools
------------------------
Prereqs:
1) Install NodeJS: http://nodejs.org/
	- Install npm package bower
		$ npm install -g bower
	- Install npm package grunt-cli
    	$ npm install -g grunt-cli

2) Install compass (requires ruby): http://compass-style.org/

3) Install git: https://help.github.com/articles/set-up-git

Project Setup:
1) Install required packages
	$ cd <project>
	$ npm install

2) Install bower packages
    $ cd <project>
    $ bower install

To init the project and start the watcher:
    $ cd <project>
	$ grunt

To run SASS watcher
    $ cd <project>
	$ grunt watch

To build optimized project
	$ grunt build

Ignoring dynamic files from checkin:
    $ cd <project>
    $ svn propset svn:ignore -F .svnignore .

Apache Conf
-----------
Download and install Apache HTTPD (http://httpd.apache.org).  Once installed,
map the project directory to to the relative URL /viewport-sample.  This is
done by adding a <Directory> directive to the httpd.conf and adding an Alias
directive to map the directory.  Also, reverse proxies must be set up for the
ideskos-viewport, ideskos-endpoints and ideskos-locale services. Below is a
sample of the changes to httpd.conf.  Make sure to replace #WORKSPACE# with the
path to the project.

<Directory "C:/#WORKSPACE#/aura-expenses/src/main/webapp">
 Order Allow,Deny
 Options Indexes FollowSymLinks
 Allow from all
</Directory>
Alias /viewport-sample "C:/#WORKSPACE#/aura-expenses/src/main/webapp"

Apache must be restarted every time the configuration changes.


Running under the Viewport
--------------------------
The easiest way toa access the local project in the Viewport is to use
FoxyProxy (http://getfoxyproxy.org). Download and install the "Standard"
version of FoxyProxy. After installing FoxyProxy, add a new proxy for
http://127.0.0.1.  Then add a URL patter for */viewport-sample*, checking the
"Whitelist" and "Wildcards" radio buttons.  Then select the mode: "Use proxies
based on their pre-defined patterns and priorties".

While FoxyProxy is enabled, any URL that matches */viewport-sample* will be
served from the local Apache server.

For more detailed information on FoxyProxy, see:
http://tech.ddscorp.net/display/ideskos/Using+FoxyProxy+to+Run+a+Viewport+Component+in+GWT+Developer+Mode

Once Apache and FoxyProxy are configured, use the following URL to run the
project:
http://prv.aos.delta.dds.net/viewport-home/#osPspId=viewport-sample


Questions/Comments
==================
If you have any questions or comments, please contact us:

Eric Bronnimann (ebronnimann@mediaocean.com)
Chris Sanborn (csanborn@mediaocean.com)
David Haber (dhaber@mediaocean.com)

